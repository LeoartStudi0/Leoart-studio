Added IMG_6254.jpeg to the LOOK WHAT WE MADE gallery as images/studio-gallery-wall.jpg. Existing photos and Square links preserved.
